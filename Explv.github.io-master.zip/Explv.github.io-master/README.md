# Explv.github.io

### Dax Path

The Dax Path tool makes use of @itsdax great web walking API https://github.com/itsdax/Runescape-Web-Walker-Engine
All credits to him.

### Generating map tiles

1. See instructions in https://github.com/Explv/osrs_map_tiles#generating-tiles

2. Test the map to ensure coordinates produced for a selection of OSRS tiles are correct, you can compare with the live version of https://explv.github.io/
